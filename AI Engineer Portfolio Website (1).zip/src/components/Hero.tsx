
import React, { useEffect } from 'react'
import { motion } from 'framer-motion'
import {ChevronDown, Download, Mail} from 'lucide-react'

const Hero = () => {
  const scrollToAbout = () => {
    document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })
  }

  const downloadCV = () => {
    // Create a realistic CV content
    const cvContent = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alex Chen - AI Engineer Resume</title>
    <style>
        body { font-family: 'Arial', sans-serif; line-height: 1.6; color: #333; max-width: 800px; margin: 0 auto; padding: 20px; }
        .header { text-align: center; border-bottom: 3px solid #2563eb; padding-bottom: 20px; margin-bottom: 30px; }
        .header h1 { color: #1e40af; margin: 0; font-size: 2.5em; }
        .header p { color: #64748b; font-size: 1.1em; margin: 5px 0; }
        .section { margin-bottom: 30px; }
        .section h2 { color: #1e40af; border-bottom: 2px solid #e2e8f0; padding-bottom: 5px; margin-bottom: 15px; }
        .job, .education, .project { margin-bottom: 20px; }
        .job h3, .education h3, .project h3 { color: #374151; margin-bottom: 5px; }
        .meta { color: #6b7280; font-style: italic; margin-bottom: 10px; }
        .skills { display: flex; flex-wrap: wrap; gap: 10px; }
        .skill { background: #eff6ff; color: #1d4ed8; padding: 5px 12px; border-radius: 20px; font-size: 0.9em; }
        ul { padding-left: 20px; }
        li { margin-bottom: 5px; }
        .contact-info { display: flex; justify-content: space-around; flex-wrap: wrap; }
        .contact-info span { margin: 5px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Alex Chen</h1>
        <p>AI Engineer | Machine Learning Specialist | Data Scientist</p>
        <div class="contact-info">
            <span>📧 alex.chen@email.com</span>
            <span>📱 +1 (555) 123-4567</span>
            <span>🔗 linkedin.com/in/alexchen-ai</span>
            <span>💻 github.com/alexchen-ai</span>
        </div>
    </div>

    <div class="section">
        <h2>Professional Summary</h2>
        <p>Passionate AI Engineer with 3+ years of experience developing cutting-edge machine learning solutions. Expertise in deep learning, computer vision, and natural language processing. Proven track record of deploying scalable AI systems that drive business value and innovation.</p>
    </div>

    <div class="section">
        <h2>Technical Skills</h2>
        <div class="skills">
            <span class="skill">Python</span>
            <span class="skill">TensorFlow</span>
            <span class="skill">PyTorch</span>
            <span class="skill">Scikit-learn</span>
            <span class="skill">Keras</span>
            <span class="skill">OpenCV</span>
            <span class="skill">Pandas</span>
            <span class="skill">NumPy</span>
            <span class="skill">Docker</span>
            <span class="skill">Kubernetes</span>
            <span class="skill">AWS</span>
            <span class="skill">GCP</span>
            <span class="skill">SQL</span>
            <span class="skill">MongoDB</span>
            <span class="skill">Git</span>
            <span class="skill">MLOps</span>
        </div>
    </div>

    <div class="section">
        <h2>Professional Experience</h2>
        
        <div class="job">
            <h3>Senior AI Engineer - TechVision Inc.</h3>
            <div class="meta">January 2022 - Present | San Francisco, CA</div>
            <ul>
                <li>Led development of computer vision system that improved product quality detection by 35%</li>
                <li>Implemented deep learning models using TensorFlow and PyTorch for real-time image analysis</li>
                <li>Designed and deployed MLOps pipeline reducing model deployment time from weeks to hours</li>
                <li>Collaborated with cross-functional teams to integrate AI solutions into production systems</li>
                <li>Mentored junior engineers and conducted technical workshops on ML best practices</li>
            </ul>
        </div>

        <div class="job">
            <h3>Machine Learning Engineer - DataFlow Solutions</h3>
            <div class="meta">June 2021 - December 2021 | Remote</div>
            <ul>
                <li>Developed NLP models for sentiment analysis achieving 92% accuracy on customer feedback</li>
                <li>Built recommendation system using collaborative filtering and deep learning techniques</li>
                <li>Optimized model performance resulting in 40% reduction in inference time</li>
                <li>Created automated data pipelines for feature engineering and model training</li>
            </ul>
        </div>

        <div class="job">
            <h3>AI Research Intern - Innovation Labs</h3>
            <div class="meta">May 2020 - August 2020 | Boston, MA</div>
            <ul>
                <li>Researched novel neural network architectures for time series forecasting</li>
                <li>Published findings in IEEE conference on machine learning applications</li>
                <li>Developed proof-of-concept models demonstrating 25% improvement over baseline</li>
            </ul>
        </div>
    </div>

    <div class="section">
        <h2>Education</h2>
        
        <div class="education">
            <h3>Master of Science in Artificial Intelligence</h3>
            <div class="meta">Stanford University | 2020 - 2022 | GPA: 3.9/4.0</div>
            <p>Specialization: Deep Learning and Computer Vision</p>
            <p>Relevant Coursework: Advanced Machine Learning, Neural Networks, Computer Vision, Natural Language Processing</p>
        </div>

        <div class="education">
            <h3>Bachelor of Science in Computer Science</h3>
            <div class="meta">UC Berkeley | 2016 - 2020 | GPA: 3.8/4.0</div>
            <p>Minor: Mathematics</p>
            <p>Relevant Coursework: Data Structures, Algorithms, Statistics, Linear Algebra</p>
        </div>
    </div>

    <div class="section">
        <h2>Key Projects</h2>
        
        <div class="project">
            <h3>Autonomous Drone Navigation System</h3>
            <div class="meta">Personal Project | 2023</div>
            <ul>
                <li>Developed CNN-based object detection and avoidance system for autonomous drones</li>
                <li>Implemented real-time path planning algorithms using reinforcement learning</li>
                <li>Achieved 95% accuracy in obstacle detection and navigation in complex environments</li>
            </ul>
        </div>

        <div class="project">
            <h3>Medical Image Analysis Platform</h3>
            <div class="meta">Healthcare AI Hackathon Winner | 2022</div>
            <ul>
                <li>Created deep learning model for early detection of skin cancer from dermoscopy images</li>
                <li>Achieved 94% sensitivity and 89% specificity using ensemble of CNN architectures</li>
                <li>Developed web application for medical professionals with intuitive interface</li>
            </ul>
        </div>

        <div class="project">
            <h3>Smart City Traffic Optimization</h3>
            <div class="meta">University Capstone Project | 2022</div>
            <ul>
                <li>Built predictive model for traffic flow optimization using LSTM networks</li>
                <li>Reduced average commute time by 18% in simulation studies</li>
                <li>Integrated real-time data from IoT sensors and weather APIs</li>
            </ul>
        </div>
    </div>

    <div class="section">
        <h2>Certifications & Awards</h2>
        <ul>
            <li>AWS Certified Machine Learning - Specialty (2023)</li>
            <li>TensorFlow Developer Certificate (2022)</li>
            <li>Google Cloud Professional ML Engineer (2022)</li>
            <li>Best Innovation Award - AI Conference 2023</li>
            <li>Dean's List - Stanford University (2021, 2022)</li>
        </ul>
    </div>

    <div class="section">
        <h2>Publications & Research</h2>
        <ul>
            <li>"Novel Approaches to Time Series Forecasting Using Transformer Networks" - IEEE ML Conference 2023</li>
            <li>"Efficient Object Detection in Resource-Constrained Environments" - AAAI 2022</li>
            <li>"Deep Learning for Medical Image Analysis: A Comprehensive Review" - Journal of AI in Medicine 2022</li>
        </ul>
    </div>
</body>
</html>
    `;

    // Create and download the CV
    const blob = new Blob([cvContent], { type: 'text/html' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'Alex_Chen_AI_Engineer_Resume.html';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  }

  const contactMe = () => {
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })
  }

  // Binary rain effect
  useEffect(() => {
    const createBinaryRain = () => {
      const binaryContainer = document.querySelector('.binary-rain')
      if (!binaryContainer) return

      const createDigit = () => {
        const digit = document.createElement('div')
        digit.className = 'binary-digit'
        digit.textContent = Math.random() > 0.5 ? '1' : '0'
        digit.style.left = Math.random() * 100 + '%'
        digit.style.animationDuration = (Math.random() * 3 + 2) + 's'
        digit.style.animationDelay = Math.random() * 2 + 's'
        
        binaryContainer.appendChild(digit)
        
        setTimeout(() => {
          if (digit.parentNode) {
            digit.parentNode.removeChild(digit)
          }
        }, 5000)
      }

      const interval = setInterval(createDigit, 200)
      
      return () => clearInterval(interval)
    }

    const cleanup = createBinaryRain()
    return cleanup
  }, [])

  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Binary Rain Container */}
      <div className="binary-rain"></div>
      
      {/* Floating Binary Numbers */}
      <div className="floating-binary floating-binary-1">
        01001001 01001110 01001110 01001111 01010110 01000001 01010100 01001001 01001111 01001110
      </div>
      <div className="floating-binary floating-binary-2">
        01000001 01001001 00100000 01000101 01001110 01000111 01001001 01001110 01000101 01000101 01010010
      </div>
      <div className="floating-binary floating-binary-3">
        01001101 01000001 01000011 01001000 01001001 01001110 01000101 00100000 01001100 01000101 01000001 01010010 01001110 01001001 01001110 01000111
      </div>
      <div className="floating-binary floating-binary-4">
        01000100 01000101 01000101 01010000 00100000 01001100 01000101 01000001 01010010 01001110 01001001 01001110 01000111
      </div>
      <div className="floating-binary floating-binary-5">
        01010000 01011001 01010100 01001000 01001111 01001110 00100000 01010100 01000101 01001110 01010011 01001111 01010010 01000110 01001100 01001111 01010111
      </div>

      {/* Animated Background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900"></div>
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        
        {/* Floating Code Elements */}
        <div className="absolute top-20 left-10 text-cyan-400/20 font-mono text-sm animate-float">
          import tensorflow as tf
        </div>
        <div className="absolute top-40 right-20 text-blue-400/20 font-mono text-sm animate-float delay-500">
          model.compile()
        </div>
        <div className="absolute bottom-40 left-20 text-cyan-400/20 font-mono text-sm animate-float delay-1000">
          neural_network.fit()
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Text Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center lg:text-left"
          >
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="mb-6"
            >
              <span className="inline-block px-4 py-2 bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/20 rounded-full text-cyan-400 text-sm font-medium mb-4">
                Available for Opportunities
              </span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6"
            >
              <span className="block text-white">AI Engineer</span>
              <span className="block bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 bg-clip-text text-transparent">
                Innovator
              </span>
              <span className="block text-slate-300">Problem Solver</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="text-xl text-slate-400 mb-8 max-w-2xl"
            >
              Transforming complex data into intelligent solutions through cutting-edge machine learning and deep learning technologies.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8 }}
              className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start"
            >
              <motion.button
                onClick={downloadCV}
                className="group relative px-8 py-4 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-lg font-semibold text-white overflow-hidden"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <span className="relative z-10 flex items-center justify-center">
                  <Download className="w-5 h-5 mr-2" />
                  Download CV
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-cyan-600 to-blue-700 opacity-0 group-hover:opacity-100 transition-opacity"></div>
              </motion.button>

              <motion.button
                onClick={contactMe}
                className="px-8 py-4 border-2 border-cyan-500 text-cyan-400 rounded-lg font-semibold hover:bg-cyan-500 hover:text-white transition-all duration-300 flex items-center justify-center"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Mail className="w-5 h-5 mr-2" />
                Get In Touch
              </motion.button>
            </motion.div>
          </motion.div>

          {/* Profile Image */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="relative mx-auto w-80 h-80 lg:w-96 lg:h-96">
              {/* Glowing Border */}
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 rounded-full blur-sm opacity-75 animate-pulse"></div>
              
              {/* Image Container */}
              <div className="relative w-full h-full bg-slate-800 rounded-full p-2">
                <img
                  src="https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=800"
                  alt="AI Engineer Profile"
                  className="w-full h-full object-cover rounded-full"
                />
              </div>

              {/* Floating Tech Icons */}
              <motion.div
                animate={{ y: [-10, 10, -10] }}
                transition={{ duration: 3, repeat: Infinity }}
                className="absolute -top-4 -right-4 bg-slate-800 p-3 rounded-full border border-cyan-500/30"
              >
                <span className="text-cyan-400 font-mono text-sm">AI</span>
              </motion.div>
              
              <motion.div
                animate={{ y: [10, -10, 10] }}
                transition={{ duration: 3, repeat: Infinity, delay: 1 }}
                className="absolute -bottom-4 -left-4 bg-slate-800 p-3 rounded-full border border-blue-500/30"
              >
                <span className="text-blue-400 font-mono text-sm">ML</span>
              </motion.div>
            </div>
          </motion.div>
        </div>

        {/* Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
        >
          <motion.button
            onClick={scrollToAbout}
            className="flex flex-col items-center text-slate-400 hover:text-cyan-400 transition-colors"
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          >
            <span className="text-sm mb-2">Scroll Down</span>
            <ChevronDown className="w-6 h-6" />
          </motion.button>
        </motion.div>
      </div>
    </section>
  )
}

export default Hero
