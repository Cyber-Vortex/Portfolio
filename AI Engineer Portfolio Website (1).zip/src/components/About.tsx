
import React from 'react'
import { motion } from 'framer-motion'
import {Brain, Code, Zap, Award} from 'lucide-react'

const About = () => {
  const stats = [
    { icon: Brain, label: 'AI Models Built', value: '15+' },
    { icon: Code, label: 'Lines of Code', value: '50K+' },
    { icon: Zap, label: 'Projects Completed', value: '8' },
    { icon: Award, label: 'Certifications', value: '5' }
  ]

  return (
    <section id="about" className="py-20 bg-slate-800/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            About <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">Me</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-cyan-400 to-blue-500 mx-auto"></div>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h3 className="text-2xl md:text-3xl font-bold mb-6 text-white">
              Passionate about <span className="text-cyan-400">Artificial Intelligence</span>
            </h3>
            
            <div className="space-y-6 text-slate-300 text-lg leading-relaxed">
              <p>
                I'm an aspiring AI Engineer with a deep passion for machine learning and artificial intelligence. 
                My journey began with curiosity about how machines can learn and make decisions, leading me to 
                dive deep into the world of neural networks, deep learning, and intelligent systems.
              </p>
              
              <p>
                With extensive experience in <span className="text-cyan-400 font-semibold">Python</span>, 
                <span className="text-blue-400 font-semibold"> TensorFlow</span>, and 
                <span className="text-purple-400 font-semibold"> PyTorch</span>, I've developed and deployed 
                multiple machine learning models that solve real-world problems. From computer vision projects 
                to natural language processing applications, I thrive on turning complex data into actionable insights.
              </p>
              
              <p>
                My approach combines theoretical knowledge with practical implementation, always staying 
                current with the latest AI research and industry best practices. I believe in the power 
                of AI to transform industries and improve lives, and I'm excited to contribute to this 
                revolutionary field.
              </p>
            </div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              viewport={{ once: true }}
              className="mt-8"
            >
              <h4 className="text-xl font-semibold mb-4 text-white">Core Expertise</h4>
              <div className="grid grid-cols-2 gap-4">
                {[
                  'Machine Learning',
                  'Deep Learning',
                  'Computer Vision',
                  'Natural Language Processing',
                  'Data Science',
                  'Neural Networks',
                  'Model Deployment',
                  'AI Research'
                ].map((skill, index) => (
                  <motion.div
                    key={skill}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    viewport={{ once: true }}
                    className="flex items-center space-x-2"
                  >
                    <div className="w-2 h-2 bg-cyan-400 rounded-full"></div>
                    <span className="text-slate-300">{skill}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="grid grid-cols-2 gap-6"
          >
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-slate-800/80 backdrop-blur-sm border border-slate-700/50 rounded-xl p-6 text-center hover:border-cyan-500/30 transition-all duration-300 group"
                whileHover={{ y: -5 }}
              >
                <div className="relative mb-4">
                  <stat.icon className="w-10 h-10 text-cyan-400 mx-auto group-hover:scale-110 transition-transform duration-300" />
                  <div className="absolute inset-0 bg-cyan-400/20 blur-xl rounded-full opacity-0 group-hover:opacity-100 transition-opacity"></div>
                </div>
                <div className="text-3xl font-bold text-white mb-2 group-hover:text-cyan-400 transition-colors">
                  {stat.value}
                </div>
                <div className="text-slate-400 text-sm font-medium">
                  {stat.label}
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  )
}

export default About
