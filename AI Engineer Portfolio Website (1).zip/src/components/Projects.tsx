
import React from 'react'
import { motion } from 'framer-motion'
import {ExternalLink, Github, Eye} from 'lucide-react'

const Projects = () => {
  const projects = [
    {
      id: 1,
      title: 'Neural Style Transfer',
      description: 'Deep learning model that applies artistic styles to photographs using convolutional neural networks. Implemented with TensorFlow and achieved real-time processing.',
      image: 'https://images.pexels.com/photos/1181263/pexels-photo-1181263.jpeg?auto=compress&cs=tinysrgb&w=800',
      technologies: ['Python', 'TensorFlow', 'OpenCV', 'CNN'],
      github: 'https://github.com',
      demo: 'https://demo.com',
      category: 'Computer Vision'
    },
    {
      id: 2,
      title: 'Sentiment Analysis API',
      description: 'RESTful API for real-time sentiment analysis using BERT transformers. Processes social media data with 94% accuracy and handles 1000+ requests per minute.',
      image: 'https://images.pexels.com/photos/590016/pexels-photo-590016.jpg?auto=compress&cs=tinysrgb&w=800',
      technologies: ['Python', 'PyTorch', 'BERT', 'FastAPI', 'Docker'],
      github: 'https://github.com',
      demo: 'https://demo.com',
      category: 'NLP'
    },
    {
      id: 3,
      title: 'Predictive Analytics Dashboard',
      description: 'Machine learning dashboard for sales forecasting using ensemble methods. Features interactive visualizations and automated model retraining pipeline.',
      image: 'https://images.pexels.com/photos/669610/pexels-photo-669610.jpg?auto=compress&cs=tinysrgb&w=800',
      technologies: ['Python', 'Scikit-learn', 'Plotly', 'Streamlit', 'AWS'],
      github: 'https://github.com',
      demo: 'https://demo.com',
      category: 'Data Science'
    },
    {
      id: 4,
      title: 'Object Detection System',
      description: 'Real-time object detection and tracking system using YOLO v5. Deployed on edge devices with optimized inference speed for autonomous vehicle applications.',
      image: 'https://images.pexels.com/photos/2599244/pexels-photo-2599244.jpg?auto=compress&cs=tinysrgb&w=800',
      technologies: ['Python', 'PyTorch', 'YOLO', 'OpenCV', 'TensorRT'],
      github: 'https://github.com',
      demo: 'https://demo.com',
      category: 'Computer Vision'
    }
  ]

  return (
    <section id="projects" className="py-20 bg-slate-800/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Featured <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">Projects</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-cyan-400 to-blue-500 mx-auto mb-6"></div>
          <p className="text-xl text-slate-400 max-w-3xl mx-auto">
            A showcase of AI and machine learning projects that demonstrate practical problem-solving and technical expertise
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="group bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 rounded-xl overflow-hidden hover:border-cyan-500/30 transition-all duration-300"
              whileHover={{ y: -5 }}
            >
              {/* Project Image */}
              <div className="relative overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                
                {/* Category Badge */}
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 bg-cyan-500/20 border border-cyan-500/30 rounded-full text-cyan-400 text-sm font-medium backdrop-blur-sm">
                    {project.category}
                  </span>
                </div>

                {/* Hover Actions */}
                <div className="absolute bottom-4 right-4 flex space-x-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <motion.a
                    href={project.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 bg-slate-800/80 backdrop-blur-sm border border-slate-600/50 rounded-lg text-white hover:text-cyan-400 hover:border-cyan-500/50 transition-all duration-300"
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Github className="w-5 h-5" />
                  </motion.a>
                  <motion.a
                    href={project.demo}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 bg-slate-800/80 backdrop-blur-sm border border-slate-600/50 rounded-lg text-white hover:text-cyan-400 hover:border-cyan-500/50 transition-all duration-300"
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <ExternalLink className="w-5 h-5" />
                  </motion.a>
                </div>
              </div>

              {/* Project Content */}
              <div className="p-6">
                <h3 className="text-xl font-bold text-white mb-3 group-hover:text-cyan-400 transition-colors">
                  {project.title}
                </h3>
                
                <p className="text-slate-400 mb-4 leading-relaxed">
                  {project.description}
                </p>

                {/* Technologies */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.technologies.map((tech) => (
                    <span
                      key={tech}
                      className="px-3 py-1 bg-slate-700/50 border border-slate-600/30 rounded-full text-slate-300 text-sm hover:border-cyan-500/30 hover:text-cyan-400 transition-all duration-300"
                    >
                      {tech}
                    </span>
                  ))}
                </div>

                {/* Action Links */}
                <div className="flex space-x-4">
                  <a
                    href={project.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center text-slate-400 hover:text-cyan-400 transition-colors"
                  >
                    <Github className="w-4 h-4 mr-2" />
                    <span className="text-sm font-medium">View Code</span>
                  </a>
                  <a
                    href={project.demo}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center text-slate-400 hover:text-cyan-400 transition-colors"
                  >
                    <Eye className="w-4 h-4 mr-2" />
                    <span className="text-sm font-medium">Live Demo</span>
                  </a>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* View More Projects */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <motion.a
            href="https://github.com"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-slate-700 to-slate-600 border border-slate-600 rounded-lg text-white font-semibold hover:from-cyan-600 hover:to-blue-600 hover:border-cyan-500 transition-all duration-300"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Github className="w-5 h-5 mr-2" />
            View All Projects on GitHub
          </motion.a>
        </motion.div>
      </div>
    </section>
  )
}

export default Projects
