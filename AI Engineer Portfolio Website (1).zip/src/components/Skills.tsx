
import React from 'react'
import { motion } from 'framer-motion'

const Skills = () => {
  const skillCategories = [
    {
      title: 'Programming Languages',
      skills: [
        { name: 'Python', level: 95, color: 'from-cyan-400 to-cyan-600' },
        { name: 'JavaScript', level: 85, color: 'from-yellow-400 to-yellow-600' },
        { name: 'R', level: 80, color: 'from-blue-400 to-blue-600' },
        { name: 'SQL', level: 90, color: 'from-green-400 to-green-600' }
      ]
    },
    {
      title: 'AI/ML Frameworks',
      skills: [
        { name: 'TensorFlow', level: 90, color: 'from-orange-400 to-orange-600' },
        { name: 'PyTorch', level: 88, color: 'from-red-400 to-red-600' },
        { name: 'Scikit-learn', level: 92, color: 'from-purple-400 to-purple-600' },
        { name: 'Keras', level: 85, color: 'from-pink-400 to-pink-600' }
      ]
    },
    {
      title: 'Tools & Technologies',
      skills: [
        { name: 'Docker', level: 80, color: 'from-blue-400 to-blue-600' },
        { name: 'Git', level: 90, color: 'from-gray-400 to-gray-600' },
        { name: 'AWS', level: 75, color: 'from-orange-400 to-orange-600' },
        { name: 'Jupyter', level: 95, color: 'from-cyan-400 to-cyan-600' }
      ]
    },
    {
      title: 'Specializations',
      skills: [
        { name: 'Computer Vision', level: 88, color: 'from-indigo-400 to-indigo-600' },
        { name: 'NLP', level: 85, color: 'from-green-400 to-green-600' },
        { name: 'Deep Learning', level: 90, color: 'from-purple-400 to-purple-600' },
        { name: 'Data Analysis', level: 92, color: 'from-cyan-400 to-cyan-600' }
      ]
    }
  ]

  return (
    <section id="skills" className="py-20 bg-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Technical <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">Skills</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-cyan-400 to-blue-500 mx-auto mb-6"></div>
          <p className="text-xl text-slate-400 max-w-3xl mx-auto">
            A comprehensive toolkit for building intelligent systems and solving complex problems
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          {skillCategories.map((category, categoryIndex) => (
            <motion.div
              key={category.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: categoryIndex * 0.1 }}
              viewport={{ once: true }}
              className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-6 hover:border-cyan-500/30 transition-all duration-300"
            >
              <h3 className="text-xl font-semibold text-white mb-6 flex items-center">
                <div className="w-3 h-3 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full mr-3"></div>
                {category.title}
              </h3>
              
              <div className="space-y-4">
                {category.skills.map((skill, skillIndex) => (
                  <motion.div
                    key={skill.name}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5, delay: (categoryIndex * 0.1) + (skillIndex * 0.05) }}
                    viewport={{ once: true }}
                    className="group"
                  >
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-slate-300 font-medium group-hover:text-white transition-colors">
                        {skill.name}
                      </span>
                      <span className="text-slate-400 text-sm">
                        {skill.level}%
                      </span>
                    </div>
                    
                    <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        whileInView={{ width: `${skill.level}%` }}
                        transition={{ duration: 1, delay: (categoryIndex * 0.1) + (skillIndex * 0.05) + 0.3 }}
                        viewport={{ once: true }}
                        className={`h-full bg-gradient-to-r ${skill.color} rounded-full relative`}
                      >
                        <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
                      </motion.div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Additional Info */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
          className="mt-16 text-center"
        >
          <div className="bg-gradient-to-r from-slate-800/50 to-slate-700/50 backdrop-blur-sm border border-slate-600/30 rounded-xl p-8">
            <h3 className="text-2xl font-bold text-white mb-4">
              Continuous Learning Mindset
            </h3>
            <p className="text-slate-300 text-lg max-w-3xl mx-auto">
              The AI field evolves rapidly, and I'm committed to staying at the forefront of innovation. 
              Currently exploring <span className="text-cyan-400 font-semibold">Transformer architectures</span>, 
              <span className="text-blue-400 font-semibold"> MLOps practices</span>, and 
              <span className="text-purple-400 font-semibold"> edge AI deployment</span>.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

export default Skills
