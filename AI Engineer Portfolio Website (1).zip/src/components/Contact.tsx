
import React from 'react'
import { motion } from 'framer-motion'
import {Mail, Linkedin, Github, MapPin, Phone, Calendar} from 'lucide-react'

const Contact = () => {
  const contactInfo = [
    {
      icon: Mail,
      label: 'Email',
      value: 'hello@aiengineer.dev',
      href: 'mailto:hello@aiengineer.dev',
      color: 'text-cyan-400'
    },
    {
      icon: Linkedin,
      label: 'LinkedIn',
      value: '/in/ai-engineer',
      href: 'https://linkedin.com/in/ai-engineer',
      color: 'text-blue-400'
    },
    {
      icon: Github,
      label: 'GitHub',
      value: '@ai-engineer',
      href: 'https://github.com/ai-engineer',
      color: 'text-purple-400'
    },
    {
      icon: MapPin,
      label: 'Location',
      value: 'San Francisco, CA',
      href: null,
      color: 'text-green-400'
    }
  ]

  return (
    <section id="contact" className="py-20 bg-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Let's <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">Connect</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-cyan-400 to-blue-500 mx-auto mb-6"></div>
          <p className="text-xl text-slate-400 max-w-3xl mx-auto">
            Ready to discuss AI opportunities, collaborate on innovative projects, or explore how machine learning can solve your challenges
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Contact Information */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h3 className="text-2xl font-bold text-white mb-8">Get In Touch</h3>
            
            <div className="space-y-6">
              {contactInfo.map((info, index) => (
                <motion.div
                  key={info.label}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="group"
                >
                  {info.href ? (
                    <a
                      href={info.href}
                      target={info.href.startsWith('http') ? '_blank' : undefined}
                      rel={info.href.startsWith('http') ? 'noopener noreferrer' : undefined}
                      className="flex items-center p-4 bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 rounded-xl hover:border-cyan-500/30 transition-all duration-300 group-hover:transform group-hover:scale-105"
                    >
                      <div className={`p-3 ${info.color} bg-slate-700/50 rounded-lg mr-4 group-hover:scale-110 transition-transform duration-300`}>
                        <info.icon className="w-6 h-6" />
                      </div>
                      <div>
                        <div className="text-slate-400 text-sm">{info.label}</div>
                        <div className="text-white font-medium group-hover:text-cyan-400 transition-colors">
                          {info.value}
                        </div>
                      </div>
                    </a>
                  ) : (
                    <div className="flex items-center p-4 bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 rounded-xl">
                      <div className={`p-3 ${info.color} bg-slate-700/50 rounded-lg mr-4`}>
                        <info.icon className="w-6 h-6" />
                      </div>
                      <div>
                        <div className="text-slate-400 text-sm">{info.label}</div>
                        <div className="text-white font-medium">{info.value}</div>
                      </div>
                    </div>
                  )}
                </motion.div>
              ))}
            </div>

            {/* Availability */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              viewport={{ once: true }}
              className="mt-8 p-6 bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/20 rounded-xl"
            >
              <div className="flex items-center mb-3">
                <Calendar className="w-5 h-5 text-cyan-400 mr-2" />
                <span className="text-white font-semibold">Availability</span>
              </div>
              <p className="text-slate-300">
                Currently open to full-time AI Engineer positions and exciting freelance projects. 
                Available for interviews and discussions.
              </p>
            </motion.div>
          </motion.div>

          {/* Call to Action */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center lg:text-left"
          >
            <div className="relative">
              {/* Background Elements */}
              <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/10 via-blue-500/10 to-purple-500/10 rounded-3xl blur-3xl"></div>
              
              <div className="relative bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 rounded-2xl p-8">
                <h3 className="text-3xl font-bold text-white mb-6">
                  Ready to Build the Future?
                </h3>
                
                <p className="text-slate-300 text-lg mb-8 leading-relaxed">
                  Whether you're looking for an AI Engineer to join your team, need consultation 
                  on machine learning projects, or want to discuss the latest in AI research, 
                  I'd love to hear from you.
                </p>

                <div className="space-y-4">
                  <motion.a
                    href="mailto:hello@aiengineer.dev"
                    className="group relative inline-flex items-center justify-center w-full px-8 py-4 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-lg font-semibold text-white overflow-hidden"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <span className="relative z-10 flex items-center">
                      <Mail className="w-5 h-5 mr-2" />
                      Send Email
                    </span>
                    <div className="absolute inset-0 bg-gradient-to-r from-cyan-600 to-blue-700 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  </motion.a>

                  <motion.a
                    href="https://linkedin.com/in/ai-engineer"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center w-full px-8 py-4 border-2 border-cyan-500 text-cyan-400 rounded-lg font-semibold hover:bg-cyan-500 hover:text-white transition-all duration-300"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <Linkedin className="w-5 h-5 mr-2" />
                    Connect on LinkedIn
                  </motion.a>
                </div>

                {/* Response Time */}
                <div className="mt-6 text-center">
                  <p className="text-slate-400 text-sm">
                    💡 Typically responds within 24 hours
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

export default Contact
