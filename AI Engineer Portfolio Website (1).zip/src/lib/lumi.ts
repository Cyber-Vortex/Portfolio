
import { createClient } from '@lumi.new/sdk'

export const lumi = createClient({
  projectId: 'p353169767568240640',
  apiBaseUrl: 'https://api.lumi.new',
  authOrigin: 'https://auth.lumi.new',
})

